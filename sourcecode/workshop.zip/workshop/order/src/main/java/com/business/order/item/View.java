package com.business.order.item;

public class View {
    interface Summary {
    }
}
